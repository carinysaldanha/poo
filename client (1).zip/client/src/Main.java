import frames.*;
import listeners.BackButtonListener;
import listeners.Cockpit;
import listeners.NavigateButtonListener;

import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {

        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

//        // Define a fonte global para todos os componentes
//        Font novaFonte = new Font("Roboto", Font.PLAIN, 14);
//
//        // Altera a fonte para vários tipos de componentes
//        UIManager.put("Label.font", novaFonte);
//        UIManager.put("Button.font", novaFonte);
//        UIManager.put("TextField.font", novaFonte);
//        UIManager.put("TextArea.font", novaFonte);
//        UIManager.put("ComboBox.font", novaFonte);
//        UIManager.put("MenuItem.font", novaFonte);
//        UIManager.put("Table.font", novaFonte);

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                MainFrame main = new MainFrame();

                main.setVisible(true);

                Dimension size = main.getSize();

                StudentsFrame students = new StudentsFrame();
                students.setSize(size);

                students.setBackButtonListener(new BackButtonListener() {
                    @Override
                    public void backButtonPressed() {
                        students.setVisible(false);
                        main.setVisible(true);
                    }
                });

                TeachersFrame teachers = new TeachersFrame();
                teachers.setSize(size);

                teachers.setBackButtonListener(new BackButtonListener() {
                    @Override
                    public void backButtonPressed() {
                        teachers.setVisible(false);
                        main.setVisible(true);
                    }
                });

                CoursesFrame courses = new CoursesFrame();
                courses.setSize(size);

                courses.setBackButtonListener(new BackButtonListener() {
                    @Override
                    public void backButtonPressed() {
                        courses.setVisible(false);
                        main.setVisible(true);
                    }
                });

                SubjectsFrame subjects = new SubjectsFrame();
                subjects.setSize(size);

                subjects.setBackButtonListener(new BackButtonListener() {
                    @Override
                    public void backButtonPressed() {
                        subjects.setVisible(false);
                        main.setVisible(true);
                    }
                });

                DepartmentsFrame departments = new DepartmentsFrame();
                departments.setSize(size);

                departments.setBackButtonListener(new BackButtonListener() {

                    @Override
                    public void backButtonPressed() {
                        departments.setVisible(false);
                        main.setVisible(true);
                    }
                });

                main.setNavigateButtonListener(new NavigateButtonListener() {
                    @Override
                    public void navigateButtonPressed(Cockpit cockpit) {
                        System.out.println("Tela visível: " + cockpit);
                        // Aqui você pode realizar ações específicas com base no enum
                        switch (cockpit) {
                            case STUDENTS:
                                System.out.println("Abrindo tela de students...");
                                main.setVisible(false);
                                students.setVisible(true);
                                break;
                            case TEACHERS:
                                System.out.println("Abrindo tela de professores...");
                                main.setVisible(false);
                                teachers.setVisible(true);
                                break;
                            case COURSES:
                                System.out.println("Abrindo tela de cursos...");
                                main.setVisible(false);
                                courses.setVisible(true);
                                break;
                            case DISCIPLINES:
                                System.out.println("Abrindo tela de disciplinas...");
                                main.setVisible(false);
                                subjects.setVisible(true);
                                break;
                            case DEPARTMENTS:
                                System.out.println("Abrindo tela de departamentos...");
                                main.setVisible(false);
                                departments.setVisible(true);
                                break;
                            case EXIT:
                                System.out.println("Saindo...");
                                System.exit(0);
                                break;
                        }
                    }
                });
            }
        });
    }
}