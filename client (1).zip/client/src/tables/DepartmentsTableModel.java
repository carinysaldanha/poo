package tables;

import models.Department;

import javax.swing.table.DefaultTableModel;
import java.util.List;

public class DepartmentsTableModel {
    public static DefaultTableModel createTableModel(List<Department> departmentLists) {
        // Definindo os nomes das colunas da tabela
        String[] colunas = {"Código", "Nome"};

        // Criando o modelo da tabela com as colunas definidas e 0 linhas inicialmente
        DefaultTableModel modeloTabela = new DefaultTableModel(colunas, 0);

        // Iterando sobre a lista de departamentos para adicionar as linhas à tabela
        for (Department department : departmentLists) {
            Object[] row = {
                    department.getCode(),  // Código do departamento
                    department.getName()   // Nome do departamento
            };
            modeloTabela.addRow(row);  // Adicionando a linha à tabela
        }

        return modeloTabela;  // Retornando o modelo de tabela preenchido
    }
}
