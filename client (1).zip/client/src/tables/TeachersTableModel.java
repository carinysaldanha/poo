package tables;

import models.Teacher;

import javax.swing.table.DefaultTableModel;
import java.util.List;

public class TeachersTableModel {
    public static DefaultTableModel createTableModel(List<Teacher> teachersList) {
        String[] colunas = {"Matrícula", "Nome", "Endereço", "Telefone", "Especialização", "Departamento"};

        DefaultTableModel modeloTabela = new DefaultTableModel(colunas, 0);

        for (Teacher teacher : teachersList) {
            Object[] row = {
                    teacher.getCode(),
                    teacher.getName(),
                    teacher.getAddress(),
                    teacher.getPhone(),
                    teacher.getEducation(),
                    teacher.getDepartment().getName(),
            };
            modeloTabela.addRow(row);
        }

        return modeloTabela;
    }
}
