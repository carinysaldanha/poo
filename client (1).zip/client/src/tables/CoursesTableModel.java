package tables;

import models.Course;

import javax.swing.table.DefaultTableModel;
import java.util.List;

public class CoursesTableModel {
    public static DefaultTableModel createTableModel(List<Course> coursesList) {
        // Definindo os nomes das colunas da tabela
        String[] colunas = {"Código", "Nome", "Sigla"};

        // Criando o modelo da tabela com as colunas definidas e 0 linhas inicialmente
        DefaultTableModel modeloTabela = new DefaultTableModel(colunas, 0);

        // Iterando sobre a lista de cursos para adicionar as linhas à tabela
        for (Course course : coursesList) {
            Object[] row = {
                    course.getCode(),  // Código do curso
                    course.getName(),  // Nome do curso
                    course.getAbbreviation()  // Sigla do curso
            };
            modeloTabela.addRow(row);  // Adicionando a linha à tabela
        }

        return modeloTabela;  // Retornando o modelo de tabela preenchido
    }
}
