package tables;

import models.Subject;

import javax.swing.table.DefaultTableModel;
import java.util.List;

public class SubjectsTableModel {
    public static DefaultTableModel createTableModel(List<Subject> subjectList) {
        // Definindo os nomes das colunas da tabela
        String[] colunas = {"Código", "Nome", "Sigla", "Ementa", "Departamento"};

        // Criando o modelo da tabela com as colunas definidas e 0 linhas inicialmente
        DefaultTableModel modeloTabela = new DefaultTableModel(colunas, 0);

        // Iterando sobre a lista de disciplinas para adicionar as linhas à tabela
        for (Subject subject : subjectList) {
            Object[] row = {
                    subject.getCode(),           // Código da disciplina
                    subject.getName(),           // Nome da disciplina
                    subject.getAbbreviation(),   // Sigla da disciplina
                    subject.getSyllabus(),       // Ementa da disciplina
                    subject.getDepartment().getName()  // Nome do departamento
            };
            modeloTabela.addRow(row);  // Adicionando a linha à tabela
        }

        return modeloTabela;  // Retornando o modelo de tabela preenchido
    }
}
