package tables;

import models.Student;

import javax.swing.table.DefaultTableModel;
import java.util.List;

public class StudentsTableModel {
    public static DefaultTableModel createTableModel(List<Student> studentsList) {
        String[] colunas = {"Código", "Matrícula", "Nome", "Endereço", "Telefone", "Data de Nascimento", "Curso"};

        DefaultTableModel modeloTabela = new DefaultTableModel(colunas, 0);

        for (Student students : studentsList) {
            Object[] row = {
                    students.getCode(),
                    students.getEnrollmentNumber(),
                    students.getName(),
                    students.getAddress(),
                    students.getPhone(),
                    students.getBirthDate(),
                    students.getCourse().getName(),
            };
            modeloTabela.addRow(row);
        }

        return modeloTabela;
    }
}
