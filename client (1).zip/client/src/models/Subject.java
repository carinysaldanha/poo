package models;

import java.util.List;

public class Subject {
    private int code;
    private String name;
    private String abbreviation;
    private String syllabus;
    private Department department;
    private List<Course> courses;
    private List<Teacher> teachers;

    // Constructors, getters and setters
    public Subject(int code, String name, String abbreviation, String syllabus, Department department) {
        this.code = code;
        this.name = name;
        this.abbreviation = abbreviation;
        this.syllabus = syllabus;
        this.department = department;
    }

    // Getters and setters
    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public String getSyllabus() {
        return syllabus;
    }

    public void setSyllabus(String syllabus) {
        this.syllabus = syllabus;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public List<Course> getCourses() {
        return courses;
    }

    public void setCourses(List<Course> courses) {
        this.courses = courses;
    }

    public List<Teacher> getTeachers() {
        return teachers;
    }

    public void setTeachers(List<Teacher> teachers) {
        this.teachers = teachers;
    }
}
