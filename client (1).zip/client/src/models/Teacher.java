package models;

import java.util.List;

public class Teacher {
    private int code;
    private String name;
    private String education;
    private String address;
    private String phone;
    private Department department;
    private List<Subject> subjects;

    // Constructors, getters and setters
    public Teacher(int code, String name, String education, String address, String phone, Department department) {
        this.code = code;
        this.name = name;
        this.education = education;
        this.address = address;
        this.phone = phone;
        this.department = department;
    }

    // Getters and setters
    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public List<Subject> getSubjects() {
        return subjects;
    }

    public void setSubjects(List<Subject> subjects) {
        this.subjects = subjects;
    }
}
