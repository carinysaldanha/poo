package models;

import java.util.List;

public class Course {
    private int code;
    private String name;
    private String abbreviation;
    private List<Student> students;
    private List<Subject> subjects;


    public Course() {}

    // Constructors, getters and setters
    public Course(int code, String name, String abbreviation) {
        this.code = code;
        this.name = name;
        this.abbreviation = abbreviation;
    }

    // Getters and setters
    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    public List<Subject> getSubjects() {
        return subjects;
    }

    public void setSubjects(List<Subject> subjects) {
        this.subjects = subjects;
    }

    @Override
    public String toString() {
        return abbreviation + " - " + name;
    }
}
