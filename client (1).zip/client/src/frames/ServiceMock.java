package frames;

import models.*;

import java.util.ArrayList;
import java.util.List;

public class ServiceMock {
    private static ServiceMock instance;

    private final List<Department> departments;
    private final List<Subject> subjects;
    private final List<Course> courses;
    private final List<Teacher> teachers;
    private final List<Student> students;

    // Adicionando as variáveis para armazenar o último ID usado
    private int lastDepartmentId;
    private int lastSubjectId;
    private int lastCourseId;
    private int lastTeacherId;
    private int lastStudentId;

    public ServiceMock() {
        departments = new ArrayList<>();
        lastDepartmentId = 0;

        Department departamento1 = new Department(++lastDepartmentId, "Matemática");
        Department departamento2 = new Department(++lastDepartmentId, "Lingua Portuguesa");
        Department departamento3 = new Department(++lastDepartmentId, "Biologia");
        Department departamento4 = new Department(++lastDepartmentId, "Física");

        departments.add(departamento1);
        departments.add(departamento2);
        departments.add(departamento3);
        departments.add(departamento4);

        subjects = new ArrayList<>();
        lastSubjectId = 0;

        Subject disciplina1 = new Subject(++lastSubjectId, "Matemática 1", "MATH1", "Introdução à Matemática", departamento1);
        Subject disciplina2 = new Subject(++lastSubjectId, "Matemática 2", "MATH2", "Cálculo Diferencial e Integral", departamento1);
        Subject disciplina3 = new Subject(++lastSubjectId, "Literatura Brasileira", "LITBR", "Estudo das principais obras da literatura brasileira", departamento2);
        Subject disciplina4 = new Subject(++lastSubjectId, "Biologia Geral", "BIO1", "Fundamentos da Biologia", departamento3);
        Subject disciplina5 = new Subject(++lastSubjectId, "Física 1", "FIS1", "Mecânica Clássica", departamento4);

        subjects.add(disciplina1);
        subjects.add(disciplina2);
        subjects.add(disciplina3);
        subjects.add(disciplina4);
        subjects.add(disciplina5);

        courses = new ArrayList<>();
        lastCourseId = 0;

        Course curso1 = new Course(++lastCourseId, "Fundamental I", "FO1");

        courses.add(curso1);

        teachers = new ArrayList<>();
        lastTeacherId = 0;

        Teacher professor1 = new Teacher(++lastTeacherId, "Carlos Silva", "Mestrado em Matemática", "Rua X, 123", "987654321", departamento1);
        Teacher professor2 = new Teacher(++lastTeacherId, "Maria Oliveira", "Mestrado em Língua Portuguesa", "Rua Y, 456", "123456789", departamento2);
        Teacher professor3 = new Teacher(++lastTeacherId, "Roberto Santos", "Doutorado em Biologia", "Rua Z, 789", "112233445", departamento3);
        Teacher professor4 = new Teacher(++lastTeacherId, "Ana Costa", "Mestrado em Física", "Rua W, 101", "667788990", departamento4);

        teachers.add(professor1);
        teachers.add(professor2);
        teachers.add(professor3);
        teachers.add(professor4);

        students = new ArrayList<>();
        lastStudentId = 0;

        Student aluno1 = new Student(++lastStudentId, 1010, "João da Silva", "Rua A, 101", "998877665", "10/05/2010", curso1);
        Student aluno2 = new Student(++lastStudentId, 2010, "Ana Pereira", "Rua B, 202", "887766554", "15/07/2010", curso1);
        Student aluno3 = new Student(++lastStudentId, 3010, "Lucas Santos", "Rua C, 303", "776655443", "22/03/2010", curso1);
        Student aluno4 = new Student(++lastStudentId, 4010, "Mariana Oliveira", "Rua D, 404", "665544332", "18/09/2010", curso1);
        Student aluno5 = new Student(++lastStudentId, 5010, "Carlos Souza", "Rua E, 505", "554433221", "30/11/2010", curso1);

        students.add(aluno1);
        students.add(aluno2);
        students.add(aluno3);
        students.add(aluno4);
        students.add(aluno5);
    }

    public Student createStudent(
            int enrollmentNumber,
            String name,
            String address,
            String phone,
            String birthDate,
            Course course
    ) {
        return new Student(++lastStudentId, enrollmentNumber, name, address, phone, birthDate, course);
    }

    public Course createCourse(
            String name,
            String abbreviation
    ) {
        return new Course(lastCourseId++, name, abbreviation);
    }

    // Métodos para pegar o último ID utilizado
    public int getLastDepartmentId() {
        return lastDepartmentId;
    }

    public int getLastSubjectId() {
        return lastSubjectId;
    }

    public int getLastCourseId() {
        return lastCourseId;
    }

    public int getLastTeacherId() {
        return lastTeacherId;
    }

    public int getLastStudentId() {
        return lastStudentId;
    }

    public List<Department> getDepartments() {
        return departments;
    }

    public List<Course> getCourses() {
        return courses;
    }

    public List<Teacher> getTeachers() {
        return teachers;
    }

    public List<Subject> getSubjects() {
        return subjects;
    }

    public List<Student> getStudents() {
        return students;
    }

    public static ServiceMock getInstance() {
        if (instance == null) {
            instance = new ServiceMock();
        }

        return instance;
    }
}