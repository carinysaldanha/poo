package frames;

import listeners.BackButtonListener;
import models.Subject;
import tables.SubjectsTableModel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class SubjectsFrame extends JFrame {
    private JPanel contentPanel;
    private JPanel header;
    private JScrollPane mainPanel;
    private JTextField nameTextField;
    private JPanel actionsPanel;
    private JButton saveButton;
    private JButton backButton;
    private JPanel asidePanel;
    private JTable students;
    private JTextField abbreviationTextField;
    private JTextField syllabusTextField;
    private JComboBox departmentsComboBox;

    private BackButtonListener backButtonListener;

    public SubjectsFrame() {
        setTitle("Sistema de Gerenciamento Escolar - Gerenciar Disciplinas");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(contentPanel);

        setSize(800, 500);

        setLocationRelativeTo(null);

        List<Subject> subjectList = getSubjects();

        DefaultTableModel modeloTabela = SubjectsTableModel.createTableModel(subjectList);
        students.setModel(modeloTabela);

        students.getColumnModel().getColumn(0).setPreferredWidth(100); // Coluna "Código"
        students.getColumnModel().getColumn(1).setPreferredWidth(150); // Coluna "Nome"
        students.getColumnModel().getColumn(2).setPreferredWidth(120); // Coluna "Abreviação"
        students.getColumnModel().getColumn(3).setPreferredWidth(200); // Coluna "Ementa"

        for (int i = 0; i < students.getColumnCount(); i++) {
            students.getColumnModel().getColumn(i).setResizable(false);
        }

        pack();
        
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                back();
            }
        });
    }

    private static List<Subject> getSubjects() {
        return ServiceMock.getInstance().getSubjects();
    }

    public void setBackButtonListener(BackButtonListener backButtonListener) {
        this.backButtonListener = backButtonListener;
    }

    private void back() {
        if (backButtonListener != null) {
            this.backButtonListener.backButtonPressed();
        }
    }
}
