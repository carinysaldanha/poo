package frames;

import listeners.BackButtonListener;
import models.Course;
import models.Teacher;
import tables.TeachersTableModel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class TeachersFrame extends JFrame {
    private JPanel contentPanel;
    private JPanel header;
    private JTextField registrationTextField;
    private JScrollPane mainPanel;
    private JTextField nameTextField;
    private JTextField addressTextField;
    private JTextField phoneTextField;
    private JTextField specializationTextField;
    private JComboBox<Course> departmentComboBox;
    private JPanel actionsPanel;
    private JButton saveButton;
    private JButton backButton;
    private JPanel asidePanel;
    private JTable teachers;

    private BackButtonListener backButtonListener;

    public TeachersFrame() {
        setTitle("Sistema de Gerenciamento Escolar - Gerenciar Professores");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(contentPanel);

        setSize(800, 500);

        setLocationRelativeTo(null);

        List<Teacher> teachersList = getTeachers();

        DefaultTableModel teachersTableModel = TeachersTableModel.createTableModel(teachersList);
        teachers.setModel(teachersTableModel);

        teachers.getColumnModel().getColumn(0).setPreferredWidth(100); // Coluna "Matrícula"
        teachers.getColumnModel().getColumn(1).setPreferredWidth(150); // Coluna "Nome"
        teachers.getColumnModel().getColumn(2).setPreferredWidth(200); // Coluna "Endereço"
        teachers.getColumnModel().getColumn(3).setPreferredWidth(120); // Coluna "Telefone"
        teachers.getColumnModel().getColumn(4).setPreferredWidth(150); // Coluna "Data de Nascimento"
        teachers.getColumnModel().getColumn(5).setPreferredWidth(120); // Coluna "Curso"

        for (int i = 0; i < teachers.getColumnCount(); i++) {
            teachers.getColumnModel().getColumn(i).setResizable(false);
        }

        pack();
        
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                back();
            }
        });
    }

    private static List<Teacher> getTeachers() {
        return ServiceMock.getInstance().getTeachers();
    }

    public void setBackButtonListener(BackButtonListener backButtonListener) {
        this.backButtonListener = backButtonListener;
    }

    private void back() {
        if (backButtonListener != null) {
            this.backButtonListener.backButtonPressed();
        }
    }
}
