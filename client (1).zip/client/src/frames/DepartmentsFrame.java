package frames;

import listeners.BackButtonListener;
import models.Department;
import tables.DepartmentsTableModel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class DepartmentsFrame extends JFrame {
    private JPanel contentPanel;
    private JPanel header;
    private JScrollPane mainPanel;
    private JTextField nameTextField;
    private JPanel actionsPanel;
    private JButton saveButton;
    private JButton backButton;
    private JPanel asidePanel;
    private JTable students;

    private BackButtonListener backButtonListener;

    public DepartmentsFrame() {
        setTitle("Sistema de Gerenciamento Escolar - Gerenciar Cursos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(contentPanel);

        setSize(800, 500);

        setLocationRelativeTo(null);

        List<Department> departmentLists = getDepartments();

        DefaultTableModel modeloTabela = DepartmentsTableModel.createTableModel(departmentLists);
        students.setModel(modeloTabela);

        students.getColumnModel().getColumn(0).setPreferredWidth(50); // Coluna "Código"
        students.getColumnModel().getColumn(1).setPreferredWidth(200); // Coluna "Nome"

        for (int i = 0; i < students.getColumnCount(); i++) {
            students.getColumnModel().getColumn(i).setResizable(false);
        }

        pack();
        
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                back();
            }
        });
    }

    private static List<Department> getDepartments() {
        return ServiceMock.getInstance().getDepartments();
    }

    public void setBackButtonListener(BackButtonListener backButtonListener) {
        this.backButtonListener = backButtonListener;
    }

    private void back() {
        if (backButtonListener != null) {
            this.backButtonListener.backButtonPressed();
        }
    }
}
