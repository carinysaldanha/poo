package frames;

import listeners.BackButtonListener;
import models.Course;
import models.Department;
import tables.CoursesTableModel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class CoursesFrame extends JFrame {
    private JPanel contentPanel;
    private JPanel header;
    private JScrollPane mainPanel;
    private JTextField nameTextField;
    private JTextField abbreviationTextField;
    private JComboBox<Department> departmentsComboBox;
    private JPanel actionsPanel;
    private JButton saveButton;
    private JButton backButton;
    private JPanel asidePanel;
    private JTable students;

    private BackButtonListener backButtonListener;

    public CoursesFrame() {
        setTitle("Sistema de Gerenciamento Escolar - Gerenciar Cursos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(contentPanel);

        setSize(800, 500);

        setLocationRelativeTo(null);

        List<Course> coursesList = getCourses();

        DefaultTableModel modeloTabela = CoursesTableModel.createTableModel(coursesList);
        students.setModel(modeloTabela);

        students.getColumnModel().getColumn(0).setPreferredWidth(100); // Coluna "Código"
        students.getColumnModel().getColumn(1).setPreferredWidth(150); // Coluna "Nome"
        students.getColumnModel().getColumn(2).setPreferredWidth(120); // Coluna "Abreviação"

        for (int i = 0; i < students.getColumnCount(); i++) {
            students.getColumnModel().getColumn(i).setResizable(false);
        }

        populateDepartmentsComboBox();

        pack();

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                back();
            }
        });
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Course course = ServiceMock.getInstance().createCourse(
                        nameTextField.getText(),
                        abbreviationTextField.getText()
                );

                ServiceMock.getInstance().getCourses().add(course);
                List<Course> updatedCourses = ServiceMock.getInstance().getCourses();

                DefaultTableModel modeloTabela = CoursesTableModel.createTableModel(updatedCourses);
                students.setModel(modeloTabela);

                nameTextField.setText("");
                abbreviationTextField.setText("");
            }
        });
    }

    private void populateDepartmentsComboBox() {
        List<Department> departments = ServiceMock.getInstance().getDepartments();
        DefaultComboBoxModel<Department> departmentsModel = new DefaultComboBoxModel<>();

        for (Department department : departments) {
            departmentsModel.addElement(department);
        }

        departmentsComboBox.setModel(departmentsModel);
    }

    private static List<Course> getCourses() {
        return ServiceMock.getInstance().getCourses();
    }

    public void setBackButtonListener(BackButtonListener backButtonListener) {
        this.backButtonListener = backButtonListener;
    }

    private void back() {
        if (backButtonListener != null) {
            this.backButtonListener.backButtonPressed();
        }
    }
}
