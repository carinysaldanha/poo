package frames;

import listeners.Cockpit;
import listeners.NavigateButtonListener;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame {
    private JPanel contentPanel;
    private JPanel asidePanel;
    private JPanel mainPanel;

    private JButton studentsButton;
    private JButton teachersButton;
    private JButton coursesButton;
    private JButton disciplinesButton;
    private JButton departmentsButton;
    private JButton exitButton;

    private JLabel labelImage;

    private NavigateButtonListener navigateButtonListener;

    public MainFrame() {
        setTitle("Sistema de Gerenciamento Escolar");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(contentPanel);

        setSize(800, 500);

        setLocationRelativeTo(null);

        configureButtons();
    }

    private void configureButtons() {
        studentsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                navigateButtonPressed(Cockpit.STUDENTS);
            }
        });

        teachersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                navigateButtonPressed(Cockpit.TEACHERS);
            }
        });

        coursesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                navigateButtonPressed(Cockpit.COURSES);
            }
        });

        disciplinesButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                navigateButtonPressed(Cockpit.DISCIPLINES);
            }
        });

        departmentsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                navigateButtonPressed(Cockpit.DEPARTMENTS);
            }
        });

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                navigateButtonPressed(Cockpit.EXIT);
            }
        });
    }

    public void setNavigateButtonListener(NavigateButtonListener navigateButtonListener) {
        this.navigateButtonListener = navigateButtonListener;
    }

    private void navigateButtonPressed(Cockpit cockpit) {
        if (navigateButtonListener != null) {
            navigateButtonListener.navigateButtonPressed(cockpit);
        }
    }
}
