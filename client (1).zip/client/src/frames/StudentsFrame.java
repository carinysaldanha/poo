package frames;

import listeners.BackButtonListener;
import models.Course;
import models.Student;
import tables.StudentsTableModel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class StudentsFrame extends JFrame {
    private JPanel contentPanel;
    private JPanel header;
    private JTextField registrationTextField;
    private JScrollPane mainPanel;
    private JTextField nameTextField;
    private JTextField addressTextField;
    private JTextField phoneTextField;
    private JTextField birthDateTextField;
    private JComboBox<Course> courseComboBox;
    private JPanel actionsPanel;
    private JButton saveButton;
    private JButton backButton;
    private JPanel asidePanel;
    private JTable students;

    private BackButtonListener backButtonListener;

    public StudentsFrame() {
        setTitle("Sistema de Gerenciamento Escolar - Gerenciar Estudantes");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(contentPanel);

        setSize(800, 500);

        setLocationRelativeTo(null);

        List<Student> studentsList = getStudents();

        DefaultTableModel modeloTabela = StudentsTableModel.createTableModel(studentsList);
        students.setModel(modeloTabela);

        students.getColumnModel().getColumn(0).setPreferredWidth(100); // Coluna "Matrícula"
        students.getColumnModel().getColumn(1).setPreferredWidth(150); // Coluna "Nome"
        students.getColumnModel().getColumn(2).setPreferredWidth(200); // Coluna "Endereço"
        students.getColumnModel().getColumn(3).setPreferredWidth(120); // Coluna "Telefone"
        students.getColumnModel().getColumn(4).setPreferredWidth(150); // Coluna "Data de Nascimento"
        students.getColumnModel().getColumn(5).setPreferredWidth(120); // Coluna "Curso"

        for (int i = 0; i < students.getColumnCount(); i++) {
            students.getColumnModel().getColumn(i).setResizable(false);
        }

        populateCoursesComboBox();

        pack();
        
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                back();
            }
        });

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int enrollmentNumber = Integer.parseInt(registrationTextField.getText());
                Course course = (Course) courseComboBox.getSelectedItem();

                Student student = ServiceMock.getInstance().createStudent(
                        enrollmentNumber,
                        nameTextField.getText(),
                        addressTextField.getText(),
                        phoneTextField.getText(),
                        birthDateTextField.getText(),
                        course
                );

                ServiceMock.getInstance().getStudents().add(student);

                List<Student> updatedStudentsList = getStudents();
                DefaultTableModel modeloTabela = StudentsTableModel.createTableModel(updatedStudentsList);
                students.setModel(modeloTabela);

                registrationTextField.setText("");
                nameTextField.setText("");
                addressTextField.setText("");
                phoneTextField.setText("");
                birthDateTextField.setText("");
                courseComboBox.setSelectedIndex(0);
            }
        });
    }

    private void populateCoursesComboBox() {
        List<Course> courses = ServiceMock.getInstance().getCourses();

        DefaultComboBoxModel<Course> coursesModel = new DefaultComboBoxModel<>();

        for (Course course : courses) {
            coursesModel.addElement(course);
        }

        courseComboBox.setModel(coursesModel);
    }

    private static List<Student> getStudents() {
        return ServiceMock.getInstance().getStudents();
    }

    public void setBackButtonListener(BackButtonListener backButtonListener) {
        this.backButtonListener = backButtonListener;
    }

    private void back() {
        if (backButtonListener != null) {
            this.backButtonListener.backButtonPressed();
        }
    }
}
