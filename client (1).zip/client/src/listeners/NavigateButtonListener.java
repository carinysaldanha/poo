package listeners;

public interface NavigateButtonListener {
    void navigateButtonPressed(Cockpit cockpit);
}
