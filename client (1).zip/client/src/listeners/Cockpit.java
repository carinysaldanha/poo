package listeners;

public enum Cockpit {
    STUDENTS,
    TEACHERS,
    COURSES,
    DISCIPLINES,
    DEPARTMENTS,
    EXIT
}
