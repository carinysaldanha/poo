package listeners;

public interface BackButtonListener {
    void backButtonPressed();
}
